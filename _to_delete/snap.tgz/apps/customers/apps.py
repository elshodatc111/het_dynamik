from django.apps import AppConfig


class CustomersConfig(AppConfig):
    name = "apps.customers"
    verbose_name = "Customer"
